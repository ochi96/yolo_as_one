cd yolor

python3 detect.py --source 0 --cfg cfg/yolor_p6.cfg --weights ./weights/yolor_p6.pt --conf 0.25 --img-size 1280 --device cpu