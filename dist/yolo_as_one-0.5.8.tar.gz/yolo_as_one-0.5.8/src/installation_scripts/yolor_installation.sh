

git clone https://github.com/ochi96/yolor.git

cd yolor

mkdir -p weights

gdown https://drive.google.com/uc?id=13lZlcjo-9uqU0MnV1lfG4YqPot4twqUi -O ./weights/yolor_p6.pt

