cd yolov5

python3 detect.py --source data/images/zidane.jpg
